# test_rule.py - Тестовый файл с нашим секретом

# Это тестовый API ключ для нашего правила
MY_CUSTOM_API_KEY = "CUSTOM-API-KEY-12345-ABCDE-67890"

# Обычный код
def hello():
    print("Hello World")

# Еще один тестовый секрет
DATABASE_PASSWORD = "SUPER-SECRET-DB-PASS-2024"